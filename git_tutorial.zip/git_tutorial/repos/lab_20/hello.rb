# Default is World
# Author: Ismail Dhorat (ismail@somewhere.com)
name = ARGV.first || "World"

puts "Hello, #{name}!"
